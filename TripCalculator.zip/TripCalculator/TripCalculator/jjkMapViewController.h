//
//  jjkMapViewController.h
//  TripCalculator
//
//  Created by Joshua Kuiros on 11/12/13.
//  Copyright (c) 2013 Joshua Kuiros. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jjkMapViewController : UIViewController

@end
