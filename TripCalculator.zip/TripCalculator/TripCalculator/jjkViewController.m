//
//  jjkViewController.m
//  TripCalculator
//
//  Created by Joshua Kuiros on 11/12/13.
//  Copyright (c) 2013 Joshua Kuiros. All rights reserved.
//

#import "jjkViewController.h"

@interface jjkViewController ()

@end

@implementation jjkViewController

- (void)viewDidLoad
{
    
    NSLog(@"Current identifier: %@", [[NSBundle mainBundle] bundleIdentifier]);
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
