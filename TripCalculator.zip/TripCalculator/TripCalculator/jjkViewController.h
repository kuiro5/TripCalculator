//
// Mike Green Josh Kuiros
// Final Project
// 12/16/13
//

#import <UIKit/UIKit.h>
#import "Model.h"
#import "jjkMapViewController.h"
#import "jjkGraphViewController.h"

@interface jjkViewController : UIViewController <UIScrollViewDelegate>

@property (strong,nonatomic) Model *model;

@end
